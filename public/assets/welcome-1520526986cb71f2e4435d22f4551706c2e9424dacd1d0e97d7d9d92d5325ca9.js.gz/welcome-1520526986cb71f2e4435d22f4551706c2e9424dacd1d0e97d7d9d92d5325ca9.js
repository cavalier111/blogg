
function main(){
 	$('.welcome').hide();
	}
$(document).ready(main);
$(document).on('page:change', main);
